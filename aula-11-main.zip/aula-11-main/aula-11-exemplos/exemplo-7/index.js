
const somarNumeros = function(numero1, numero2) {
    const soma = numero1 + numero2
    return soma
}

let multiplicarNumeros = (numero1, numero2) => {
    let produto = numero1 * numero2
    return produto
}


console.log(somarNumeros(5, 10))
console.log(multiplicarNumeros(10, 25))
