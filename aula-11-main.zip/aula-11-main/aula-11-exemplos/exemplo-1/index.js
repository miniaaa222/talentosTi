
function imprimirOla () {
    console.log("Hello, world!")
}

imprimirOla()
