
function calcularArea (altura, largura) {
    const area = altura * largura
    return area
}

let areaCalculada = calcularArea(3, 4)

console.log(areaCalculada)
