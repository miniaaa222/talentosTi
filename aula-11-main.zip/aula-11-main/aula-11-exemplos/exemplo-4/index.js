
function somarNumeros (numero1, numero2) {
    const soma = numero1 + numero2
    return soma
}

let calculo = somarNumeros(1, 10)

console.log(calculo)
