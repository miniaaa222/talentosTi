
function calcularArea (altura, largura) {
    const area = altura * largura
    console.log(area)
}

calcularArea(3, 4)
