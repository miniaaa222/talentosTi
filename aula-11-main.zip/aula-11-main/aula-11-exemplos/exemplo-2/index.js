
function imprimirNome (nome) {
    console.log(`Olá, ${nome}!`)
}

imprimirNome("Jesus")
imprimirNome("Maria")
imprimirNome("José")
